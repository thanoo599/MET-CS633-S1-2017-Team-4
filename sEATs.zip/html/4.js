var appDetails=[];
appDetails[0]='MM/DD/YYYY';
appDetails[1]='$';
appDetails[2]='999-999-9999';
