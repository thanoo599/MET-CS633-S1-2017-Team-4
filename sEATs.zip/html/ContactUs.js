////Please don't disturb this commented line
/**///Please don't disturb this commented line

function objectVisibilityDynmic(){}

function calConditionDynmic(){}